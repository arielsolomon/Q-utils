rabbitmq_exchange_name = 'pipeline'
